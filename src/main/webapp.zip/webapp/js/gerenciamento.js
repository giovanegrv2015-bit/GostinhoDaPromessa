let codigoBarrasAtual = null;
let todosProudutos = [];

const BASE_URL = "/api/estoque";

document.addEventListener("DOMContentLoaded", () => {
    carregarProdutos();

    document.getElementById("modal-quantidade").addEventListener("input", calcularTottal);
    document.getElementById("modal-valor").addEventListener("input", calcularTotal);

    document.getElementById("buscarGerenciamento").addEventListener("input", (e) => {
});
});

async function carregarProdutos(busca = "") {
    const container = document.getElementById("listarProdutos");
    container.innerHTML = '<div class="loading-msg">Carregando produtos...</div';

    try {
        let url = BASE_URL;
        if(busca) {
            url += `?nome=${encodeURIComponent(busca)}`;
        }

        const response = await fetch(url);
        if(response.ok) {
            produtosAtuais = await response.json();
        } else {
            container.innerHTML = '<p class="error-msg">Falha de conexão com o servidor.</p>';
        }
}

function renderizarProdutos(lista) {
    const container = document.getElementById("listarProdutos");
    container.innerHTML = "";

    if(lista.length === 0) {
        container.innerHTML = '<p class="sem-resultado">Nenhum produto encontrado.</p>';
        return;
    }

    lista.forEach(produto => {
        const card = document.createElement("div");
        card.className = "card-propduto";

        const badgeClass = produto.status === "entrada" ? "badge-entrada" : "badge-saida";

        card.innerHTML = `
        <div class="card-nome">${produto.nomeProduto}</div>
        <div class="card-info">Marca: <span>${produto.marca || '-'}</span></div>
        <div class="card-info">Qtd: <span>${produto.quantidade}</span></div>
        <div class="card-info">Valor: Unit.: <span>R$ ${parseFloat(produto.valor).toFixed(2)}</span></div>
        <span class="badge-status ${badgeClass}">${produto.status}</span>
        <button class="btn-gerenciar" onclick="abrirModal('${produto.codigoBarras}')">Editar</button>
        `
        container.appendChild(card);
    });
}

function
